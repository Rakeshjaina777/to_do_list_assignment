import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Flutter To-Do List App';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const TodoHomePage(),
    );
  }
}

class TodoHomePage extends StatefulWidget {
  const TodoHomePage({Key? key}) : super(key: key);

  @override
  State<TodoHomePage> createState() => _TodoHomePageState();
}

class _TodoHomePageState extends State<TodoHomePage> {
  final TaskController _taskController = TaskController();
  final TextEditingController _taskControllerInput = TextEditingController();

  void _addTask() {
    if (_taskControllerInput.text.isNotEmpty) {
      _taskController.addTask(_taskControllerInput.text);
      _taskControllerInput.clear();
      setState(() {});
    }
  }

  @override
  void dispose() {
    _taskControllerInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('To-Do List'),
        backgroundColor: Colors.blueAccent,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: _taskController.tasks.isEmpty
                ? const Center(
                    child: Text(
                      'No tasks yet! Add one to get started.',
                      style: TextStyle(fontSize: 16),
                    ),
                  )
                : ListView.builder(
                    itemCount: _taskController.tasks.length,
                    itemBuilder: (context, index) {
                      final task = _taskController.tasks[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        elevation: 3,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ListTile(
                          title: Text(
                            task.title,
                            style: TextStyle(
                              decoration: task.isComplete
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              fontSize: 18,
                              color:
                                  task.isComplete ? Colors.grey : Colors.black,
                            ),
                          ),
                          leading: Checkbox(
                            value: task.isComplete,
                            onChanged: (_) {
                              _taskController.toggleCompletion(index);
                              setState(() {});
                            },
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              _taskController.deleteTask(index);
                              setState(() {});
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _taskControllerInput,
                    decoration: InputDecoration(
                      hintText: 'Enter a new task',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      filled: true,
                      fillColor: Colors.grey[200],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                FloatingActionButton(
                  onPressed: _addTask,
                  child: const Icon(Icons.add),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Task {
  String title;
  bool isComplete;

  Task({required this.title, this.isComplete = false});
}

class TaskController {
  final List<Task> tasks = [];

  void addTask(String title) {
    tasks.add(Task(title: title));
  }

  void deleteTask(int index) {
    tasks.removeAt(index); // Use removeAt instead of remove(index) for a list
  }

  void toggleCompletion(int index) {
    tasks[index].isComplete = !tasks[index].isComplete;
  }
}
